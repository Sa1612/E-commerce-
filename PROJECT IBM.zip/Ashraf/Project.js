const images = [
	"Gallery0.jpg",
	"Gallery1.jpg",
	"Gallery2.jpg",
	"Gallery3.jpg",
	"Gallery4.jpg",
];
let currentIndex = 0;
const currentImage = document.getElementById("currentImage");
function updateImage() {
 	currentImage.src = images[currentIndex];
 	currentImage.alt = `images ${currentIndex + 1}`;
 	currentImage.width = 500;
 	currentImage.height = 500; 
}
function nextImage() {
 	currentIndex = (currentIndex + 1) % images.length;
 	updateImage();
}
function prevImage() {
 	currentIndex = (currentIndex - 1 + images.length) % images.length;
	 updateImage();
}
document.addEventListener("keydown", function (e) {
	 if (e.key === "ArrowRight") {
 		nextImage();
 	} 	
	else if (e.key === "ArrowLeft") {
 		prevImage();
	 }
});

updateImage();

function myFunction() {
  alert("Redeemed Successfully!");
}
const request = indexedDB.open('discountDB', 1);
        let db;

        request.onupgradeneeded = function (event) {
            db = event.target.result;
            const objectStore = db.createObjectStore('discountTable', { keyPath: 'id', autoIncrement: true });
            objectStore.createIndex('name', 'name', { unique: false });
            objectStore.createIndex('mobile', 'mobile', { unique: false });
            objectStore.createIndex('coupon', 'coupon', { unique: false });
            objectStore.createIndex('worth', 'worth', { unique: false });
        };

        request.onsuccess = function (event) {
            db = event.target.result;
        };

        function getDiscount() {
            const name = document.getElementById('Name').value;
            const mobile = document.getElementById('Mobile').value;

            if (name && mobile) {
                const couponValue = Math.floor(Math.random() * (3000 - 100 + 1)) + 100;
				var discountCode = generateRandomCode(8);
                const transaction = db.transaction(['discountTable'], 'readwrite');
                const objectStore = transaction.objectStore('discountTable');

                const request = objectStore.add({
                    name: name,
                    mobile: mobile,
                    coupon: discountCode,
                    worth: couponValue
                });

                request.onsuccess = function () {
                    alert('Congratulations! You got a discount coupon worth ' + couponValue + ' INR.\nCoupon Code: ' + discountCode);
                    displayData();
                };

                request.onerror = function () {
                    console.log('Error adding data to the database');
                };
            } else {
                alert('Please enter your name and mobile number to get a discount.');
            }
        }

		function displayData() {
			const outputTable = document.getElementById('output').getElementsByTagName('tbody')[0];
			outputTable.innerHTML = ''; 
		
			const objectStore = db.transaction(['discountTable']).objectStore('discountTable');
		
			objectStore.openCursor().onsuccess = function (event) {
				const cursor = event.target.result;
				if (cursor) {
					const row = outputTable.insertRow();
		
					const cell1 = row.insertCell(0);
					cell1.textContent = cursor.value.name;
		
					const cell2 = row.insertCell(1);
					cell2.textContent = cursor.value.mobile;
		
					const cell3 = row.insertCell(2);
					cell3.textContent = cursor.value.coupon;
		
					const cell4 = row.insertCell(3);
					cell4.textContent = cursor.value.worth + ' INR';
		
					cursor.continue();
				} else {
					console.log('No more data');
				}
			};
		}
				function generateRandomCode(length) {
			const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
			let result = '';
			for (let i = 0; i < length; i++) {
				result += characters.charAt(Math.floor(Math.random() * characters.length));
			}
			return result;
		}